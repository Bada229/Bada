public class LegacyPaymentSystem {
    public void makeLegacyPayment(String details, double value) {
        System.out.println("[LEGACY] Оплата: " + value + " KZT через старую систему (" + details + ")");
    }
}
