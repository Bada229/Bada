public class PaymentFactory {
    public static Payment createPayment(String type, String identifier) {
        return switch (type.toLowerCase()) {
            case "kaspi" -> new Kaspi(identifier);
            case "halyk" -> new Halyk(identifier);
            case "forte" -> new Forte(identifier);
            default -> throw new IllegalArgumentException("Неизвестный способ оплаты: " + type);
        };
    }
}
