import java.util.ArrayList;
import java.util.List;

public class Bank {
    private static Bank instance;
    private final List<Subscriber> subscribers = new ArrayList<>();

    private Bank() {
        System.out.println("✔ Bank instance created");
    }

    public static Bank getInstance() {
        if (instance == null) {
            instance = new Bank();
        }
        return instance;
    }

    public void subscribe(Subscriber subscriber) {
        subscribers.add(subscriber);
    }

    public void notifyAllSubscribers(String message) {
        for (Subscriber sub : subscribers) {
            sub.update(message);
        }
    }
}
