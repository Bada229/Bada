public class LegacyAdapter implements Payment {
    private final LegacyPaymentSystem legacySystem;

    public LegacyAdapter(LegacyPaymentSystem legacySystem) {
        this.legacySystem = legacySystem;
    }

    @Override
    public void pay(double amount, Bank bank) {
        legacySystem.makeLegacyPayment("Старый пользователь", amount);
        bank.notifyAllSubscribers("Legacy Payment: " + amount + " KZT");
    }
}
