public class Kaspi implements Payment {
    private String phoneNumber;

    public Kaspi(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public void pay(double amount, Bank bank) {
        System.out.println("Оплата через Kaspi: " + amount + " KZT (номер телефона: " + phoneNumber + ")");
        bank.notifyAllSubscribers("Kaspi Payment: " + amount + " KZT");
    }
}
