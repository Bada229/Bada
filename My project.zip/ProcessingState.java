public class ProcessingState implements PaymentState {
    @Override
    public void handle(PaymentContext context) {
        System.out.println("Состояние: обработка. Переход к завершению.");
        context.setState(new CompletedState());
    }
}
