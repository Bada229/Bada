public class LoggingPayment extends PaymentDecorator {
    public LoggingPayment(Payment decoratedPayment) {
        super(decoratedPayment);
    }

    @Override
    public void pay(double amount, Bank bank) {
        System.out.println("[LOG] Начинаем оплату на сумму " + amount + " KZT.");
        super.pay(amount, bank);
        System.out.println("[LOG] Оплата завершена.");
    }
}
