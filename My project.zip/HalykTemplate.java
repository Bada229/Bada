public class HalykTemplate extends PaymentTemplate {
    private final String card;

    public HalykTemplate(String card) {
        this.card = card;
    }

    @Override
    protected void verify(double amount) {
        System.out.println(" Проверка карты Halyk: " + card);
    }

    @Override
    protected void pay(double amount) {
        System.out.println(" Оплачено " + amount + " KZT через Halyk.");
    }
}
