public class KaspiTemplate extends PaymentTemplate {
    private final String phone;

    public KaspiTemplate(String phone) {
        this.phone = phone;
    }

    @Override
    protected void verify(double amount) {
        System.out.println(" Проверка Kaspi-номера: " + phone);
    }

    @Override
    protected void pay(double amount) {
        System.out.println("Оплачено " + amount + " KZT через Kaspi.");
    }
}
