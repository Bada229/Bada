public class VerifiedState implements PaymentState {
    @Override
    public void handle(PaymentContext context) {
        System.out.println("🔍 Состояние: проверено. Переход к обработке.");
        context.setState(new ProcessingState());
    }
}
