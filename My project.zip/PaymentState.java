public interface PaymentState {
    void handle(PaymentContext context);
}
