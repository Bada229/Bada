public class PayCommand implements Command {
    private final Context context;
    private final Payment payment;
    private final double amount;
    private final Bank bank;

    public PayCommand(Context context, Payment payment, double amount, Bank bank) {
        this.context = context;
        this.payment = payment;
        this.amount = amount;
        this.bank = bank;
    }

    @Override
    public void execute() {
        context.setPayment(payment);
        context.executePayment(amount, bank);
    }
}
