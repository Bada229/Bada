public abstract class PaymentTemplate {

    public final void process(double amount) {
        connect();
        verify(amount);
        pay(amount);
        close();
    }

    protected void connect() {
        System.out.println("🔌 Подключение к платёжной системе...");
    }

    protected abstract void verify(double amount);

    protected abstract void pay(double amount);

    protected void close() {
        System.out.println(" Завершение транзакции.");
    }
}
