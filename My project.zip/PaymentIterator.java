public interface PaymentIterator {
    boolean hasNext();
    Payment next();
}
