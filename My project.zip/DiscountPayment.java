public class DiscountPayment extends PaymentDecorator {
    private final double discountPercentage;

    public DiscountPayment(Payment decoratedPayment, double discountPercentage) {
        super(decoratedPayment);
        this.discountPercentage = discountPercentage;
    }

    @Override
    public void pay(double amount, Bank bank) {
        double discountedAmount = amount - (amount * discountPercentage / 100);
        System.out.println("[DISCOUNT] Применена скидка " + discountPercentage + "%. Итоговая сумма: " + discountedAmount + " KZT.");
        super.pay(discountedAmount, bank);
    }
}
