public class CompletedState implements PaymentState {
    @Override
    public void handle(PaymentContext context) {
        System.out.println("✅ Состояние: завершено. Оплата прошла успешно.");
    }
}
