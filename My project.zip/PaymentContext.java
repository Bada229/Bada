public class PaymentContext {
    private PaymentState currentState;

    public PaymentContext(PaymentState initialState) {
        this.currentState = initialState;
    }

    public void setState(PaymentState state) {
        this.currentState = state;
    }

    public void process() {
        currentState.handle(this);
    }
}
