public class TaxAuthority implements Subscriber {
    @Override
    public void update(String message) {
        System.out.println("🏦 Налоговая служба отслеживает: " + message);
    }
}
