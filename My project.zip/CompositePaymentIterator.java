import java.util.List;

public class CompositePaymentIterator implements PaymentIterator {
    private final List<CompositePayment.PaymentEntry> entries;
    private int position = 0;

    public CompositePaymentIterator(List<CompositePayment.PaymentEntry> entries) {
        this.entries = entries;
    }

    @Override
    public boolean hasNext() {
        return position < entries.size();
    }

    @Override
    public Payment next() {
        return entries.get(position++).payment;
    }
}
