public class Forte implements Payment {
    private String accountNumber;

    public Forte(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    @Override
    public void pay(double amount, Bank bank) {
        System.out.println("Оплата через Forte: " + amount + " KZT (номер счёта: " + accountNumber + ")");
        bank.notifyAllSubscribers("Forte Payment: " + amount + " KZT");
    }
}
