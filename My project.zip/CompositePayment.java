import java.util.ArrayList;
import java.util.List;

public class CompositePayment {
    private final List<PaymentEntry> entries = new ArrayList<>();
    private final Bank bank;

    public CompositePayment(Bank bank) {
        this.bank = bank;
    }

    public void add(Payment payment, double amount) {
        entries.add(new PaymentEntry(payment, amount));
    }

    public void remove(Payment payment) {
        entries.removeIf(e -> e.payment.equals(payment));
    }

    public void pay(double totalAmountIgnored) {
        for (PaymentEntry entry : entries) {
            Context context = new Context();
            Command command = new PayCommand(context, entry.payment, entry.amount, bank);
            CommandExecutor executor = new CommandExecutor();
            executor.setCommand(command);
            executor.run();
        }
    }

    public PaymentIterator iterator() {
        return new CompositePaymentIterator(entries);
    }

    public static class PaymentEntry {
        public Payment payment;
        public double amount;

        public PaymentEntry(Payment payment, double amount) {
            this.payment = payment;
            this.amount = amount;
        }
    }
}
