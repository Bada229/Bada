public class CreatedState implements PaymentState {
    @Override
    public void handle(PaymentContext context) {
        System.out.println(" Состояние: создано. Переход к проверке.");
        context.setState(new VerifiedState());
    }
}


