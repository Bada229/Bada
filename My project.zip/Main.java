import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Bank bank = Bank.getInstance();


        bank.subscribe(new Customer());
        bank.subscribe(new TaxAuthority());
        bank.subscribe(new AnalyticsService());

        System.out.println("Выберите способ оплаты:");
        System.out.println("(1) Kaspi");
        System.out.println("(2) Halyk");
        System.out.println("(3) Forte");
        System.out.println("(4) Legacy (Adapter)");
        System.out.println("(5) Template Method");
        System.out.println("(6) Составная оплата (Composite)");
        System.out.println("(7) Демонстрация State Pattern");
        System.out.println("(8) Iterator Pattern по составным платежам");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Очистка буфера


        if (choice == 6 || choice == 8) {
            CompositePayment composite = new CompositePayment(bank);

            boolean adding = true;
            while (adding) {
                System.out.println("Добавить оплату: (1) Kaspi (2) Halyk (3) Forte (0) Завершить");
                int subChoice = scanner.nextInt();
                scanner.nextLine();

                if (subChoice == 0) break;

                System.out.print("Введите идентификатор: ");
                String id = scanner.nextLine();
                System.out.print("Введите сумму: ");
                double sum = scanner.nextDouble();
                scanner.nextLine();

                Payment payment;
                switch (subChoice) {
                    case 1 -> payment = new Kaspi(id);
                    case 2 -> payment = new Halyk(id);
                    case 3 -> payment = new Forte(id);
                    default -> {
                        System.out.println(" Неверный выбор!");
                        continue;
                    }
                }

                payment = new LoggingPayment(payment);
                payment = new AntiFraudPayment(payment);
                payment = new DiscountPayment(payment, 10);

                composite.add(payment, sum);
                System.out.println(" Добавлено");
            }

            if (choice == 6) {
                System.out.println(" Выполняем составную оплату:");
                composite.pay(0);
            }

            if (choice == 8) {
                System.out.println("Итерация по платежам (Iterator Pattern):");
                PaymentIterator iterator = composite.iterator();
                while (iterator.hasNext()) {
                    Payment p = iterator.next();
                    System.out.println("→ Найден платёж: " + p.getClass().getSimpleName());
                }
            }
            return;
        }

        if (choice == 4) {
            LegacyPaymentSystem legacy = new LegacyPaymentSystem();
            Payment legacyAdapter = new LegacyAdapter(legacy);

            Payment payment = new LoggingPayment(legacyAdapter);
            payment = new DiscountPayment(payment, 5);

            Context context = new Context();
            Command command = new PayCommand(context, payment, 1000, bank);
            CommandExecutor executor = new CommandExecutor();
            executor.setCommand(command);
            executor.run();
            return;
        }

        if (choice == 5) {
            System.out.println("Template Method Оплата");
            System.out.println("Выберите систему: (1) Kaspi (2) Halyk (3) Forte");
            int tChoice = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Введите идентификатор: ");
            String id = scanner.nextLine();
            System.out.print("Введите сумму: ");
            double amountT = scanner.nextDouble();

            PaymentTemplate template;
            switch (tChoice) {
                case 1 -> template = new KaspiTemplate(id);
                case 2 -> template = new HalykTemplate(id);
                case 3 -> template = new ForteTemplate(id);
                default -> {
                    System.out.println("Неверный выбор шаблона.");
                    return;
                }
            }

            template.process(amountT);
            return;
        }

        if (choice == 7) {
            System.out.println("\n--- Демонстрация State Pattern ---");

            PaymentContext payment = new PaymentContext(new CreatedState());
            payment.process();
            payment.process();
            payment.process();
            payment.process();

            return;
        }


        String type;
        String identifier;

        switch (choice) {
            case 1 -> {
                type = "kaspi";
                System.out.print("Введите номер телефона: ");
                identifier = scanner.nextLine();
            }
            case 2 -> {
                type = "halyk";
                System.out.print("Введите номер карты: ");
                identifier = scanner.nextLine();
            }
            case 3 -> {
                type = "forte";
                System.out.print("Введите номер счёта: ");
                identifier = scanner.nextLine();
            }
            default -> {
                System.out.println(" Неверный выбор!");
                return;
            }
        }

        System.out.print("Введите сумму для оплаты: ");
        double amount = scanner.nextDouble();

        Payment payment = PaymentFactory.createPayment(type, identifier);
        payment = new LoggingPayment(payment);
        payment = new AntiFraudPayment(payment);
        payment = new DiscountPayment(payment, 10);

        Context context = new Context();
        Command command = new PayCommand(context, payment, amount, bank);
        CommandExecutor executor = new CommandExecutor();
        executor.setCommand(command);
        executor.run();
    }
}
