public class Halyk implements Payment {
    private String cardNumber;

    public Halyk(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    @Override
    public void pay(double amount, Bank bank) {
        System.out.println("Оплата через Halyk: " + amount + " KZT (номер карты: " + cardNumber + ")");
        bank.notifyAllSubscribers("Halyk Payment: " + amount + " KZT");
    }
}
