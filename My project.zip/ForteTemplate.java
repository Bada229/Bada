public class ForteTemplate extends PaymentTemplate {
    private final String account;

    public ForteTemplate(String account) {
        this.account = account;
    }

    @Override
    protected void verify(double amount) {
        System.out.println(" Проверка счёта Forte: " + account);
    }

    @Override
    protected void pay(double amount) {
        System.out.println(" Оплачено " + amount + " KZT через Forte.");
    }
}
