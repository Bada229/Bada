public class AntiFraudPayment extends PaymentDecorator {
    public AntiFraudPayment(Payment decoratedPayment) {
        super(decoratedPayment);
    }

    @Override
    public void pay(double amount, Bank bank) {
        if (amount > 1_000_000) {
            System.out.println("[SECURITY ALERT] Подозрительный платёж! Отклонено.");
            return;
        }
        System.out.println("[SECURITY] Проверка на мошенничество пройдена.");
        super.pay(amount, bank);
    }
}
