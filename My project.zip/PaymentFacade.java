public class PaymentFacade {
    public void makeFullPayment(String type, String identifier, double amount) {
        Bank bank = Bank.getInstance();

        Payment payment = PaymentFactory.createPayment(type, identifier);

        payment = new LoggingPayment(payment);
        payment = new AntiFraudPayment(payment);
        payment = new DiscountPayment(payment, 10);

        Context context = new Context();
        Command command = new PayCommand(context, payment, amount, bank);

        CommandExecutor executor = new CommandExecutor();
        executor.setCommand(command);
        executor.run();
    }
}
