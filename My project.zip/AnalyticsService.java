public class AnalyticsService implements Subscriber {
    @Override
    public void update(String message) {
        System.out.println("📊 Аналитика: транзакция записана -> " + message);
    }
}
