public class Customer implements Subscriber {
    @Override
    public void update(String message) {
        System.out.println("👤 Customer получил уведомление: " + message);
    }
}
